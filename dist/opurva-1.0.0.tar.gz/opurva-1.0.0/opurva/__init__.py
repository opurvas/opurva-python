# __init__.py
name = "opurva"

__version__ = "1.0.0"
